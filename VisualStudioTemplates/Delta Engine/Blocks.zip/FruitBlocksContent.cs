namespace $safeprojectname$
{
	public class FruitBlocksContent : BlocksContent
	{
		public FruitBlocksContent() : base("FruitBlocks_")
		{
			DoBricksSplitInHalfWhenRowFull = true;
		}
	}
}