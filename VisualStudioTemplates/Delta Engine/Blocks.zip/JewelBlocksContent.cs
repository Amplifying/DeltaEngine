namespace $safeprojectname$
{
	/// <summary>
	/// Loads JewelBlocks related content and settings
	/// </summary>
	public class JewelBlocksContent : BlocksContent
	{
		public JewelBlocksContent()
			: base("JewelBlocks_") {}
	}
}