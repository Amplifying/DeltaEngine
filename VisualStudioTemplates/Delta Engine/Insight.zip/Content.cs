namespace $safeprojectname$
{
	public enum Content
	{
		$safeprojectname$AppMain,
		Z$safeprojectname$Test
	}
}
