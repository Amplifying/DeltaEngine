namespace $safeprojectname$.Content
{
	public enum Buttons
	{
		ButtonContinue,
		UIUnicornSpecialAttackIntervention,
		UIUnicornSpecialAttackSwap,
		UIDragonSpecialAttackBreath,
		UIDragonSpecialAttackCannon
	}
}