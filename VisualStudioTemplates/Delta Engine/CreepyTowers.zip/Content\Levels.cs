namespace $safeprojectname$.Content
{
	public enum Levels
	{
		LevelsChildrensRoomInfo,
		LevelsBathRoomInfo,
		LevelsLivingRoomInfo
	}
}