namespace $safeprojectname$.Towers
{
	public enum TowerType
	{
		Acid,
		Fire,
		Ice,
		Impact,
		Slice,
		Water
	}
}