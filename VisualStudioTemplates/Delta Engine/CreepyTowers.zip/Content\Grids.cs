namespace $safeprojectname$.Content
{
	public enum Grids
	{
		LevelsChildsRoomGrid,
		LevelsBathroomGrid,
		LevelsLivingRoomGrid
	}
}